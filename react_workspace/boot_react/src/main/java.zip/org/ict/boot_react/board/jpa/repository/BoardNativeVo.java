package org.ict.boot_react.board.jpa.repository;

public interface BoardNativeVo {
    int getBoard_num();
    String getBoard_title();
    String getBoard_writer();
    int getBoard_readcount();
}
