package org.ict.boot_react;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootReactApplication {

    public static void main(String[] args) {
        SpringApplication.run(BootReactApplication.class, args);
    }

}
