package org.ict.testjpa.board.service;

import org.ict.testjpa.board.dto.Board;

import java.util.List;

public interface BoardService {
    public List<Board> selectList();
    public Board selectBoard(int boardNum);
    public void insertBoard(Board board);
    public void updateBoard(Board board);
    public void deleteBoard(int boardNum);
}
