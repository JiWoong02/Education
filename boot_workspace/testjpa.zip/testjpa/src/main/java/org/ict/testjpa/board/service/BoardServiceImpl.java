package org.ict.testjpa.board.service;

import lombok.RequiredArgsConstructor;
import org.ict.testjpa.board.dto.Board;
import org.ict.testjpa.board.jpa.BoardRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Properties;

@RequiredArgsConstructor
@Service
public class BoardServiceImpl implements BoardService {

    private final BoardRepository repository;

    @Override
    @Transactional
    public List<Board> selectList() {
        return repository.findAll(Sort.by(Sort.Direction.DESC, "boardNum"));
    }

    @Override
    public Board selectBoard(int boardNum) {
        return null;
    }

    @Override
    public void insertBoard(Board board) {

    }

    @Override
    public void updateBoard(Board board) {

    }

    @Override
    public void deleteBoard(int boardNum) {

    }
}
