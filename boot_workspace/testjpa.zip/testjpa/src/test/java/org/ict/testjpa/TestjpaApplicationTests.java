package org.ict.testjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestjpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
