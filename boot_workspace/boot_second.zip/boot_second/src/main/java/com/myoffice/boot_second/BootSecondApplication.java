package com.myoffice.boot_second;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootSecondApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootSecondApplication.class, args);
	}

}
