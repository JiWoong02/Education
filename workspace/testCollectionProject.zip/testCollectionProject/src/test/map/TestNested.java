package test.map;

public class TestNested {

	public static void main(String[] args) {
		// 내부 정적 인터페이스 사용 테스트
		//외부인터페이스명.내부인터페이스명 레퍼런스;
		FMap.FEntry entry;
		//Nested 클래스/인터페이스는 단독 사용 못함
		//FEntry ent;  //error

	}

}
